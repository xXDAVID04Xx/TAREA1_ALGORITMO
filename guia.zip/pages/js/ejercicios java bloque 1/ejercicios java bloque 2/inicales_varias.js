 function obtenerIniciales() {
  let nombres = ["Luis Alfonso Diaz", "Jhon Alex Castaño"];
  let salida = nombres.map(n => 
    `${n} → ${n.split(" ").map(p => p[0].toUpperCase()).join(".")}.`
  ).join("<br>");
  document.getElementById("salida").innerHTML = salida;
}