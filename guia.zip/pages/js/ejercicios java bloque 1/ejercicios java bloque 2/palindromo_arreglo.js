function palindromosEnArreglo() {
  let palabras = ["radar", "oso", "pozo"];
  let salida = palabras.map(p => 
  p === p.split("").reverse().join("") ? `${p} → es palíndromo` : `${p} → no es palíndromo`
  ).join("<br>");
  document.getElementById("salida").innerHTML = salida;
}