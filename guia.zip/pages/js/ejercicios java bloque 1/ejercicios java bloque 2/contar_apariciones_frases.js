function contarApariciones() {
    let frases = ["Adoro despertar temprano", "Estudio en Milagro"];
    let letra = "a";
    let salida = frases.map((f, i) => 
    `En la ${i+1}ª frase, la '${letra}' aparece ${f.toLowerCase().split(letra).length - 1} veces.`
  ).join("<br>");
  document.getElementById("salida").innerHTML = salida;
}