function fraseConMasCaracteres() {
      let pares = [["No me gusta la comida", "Soy más de estar en casa"], ["Guayaco", "Personalizado"]];
      let salida = pares.map(([a,b]) => 
        a.length > b.length ? `${a} → más caracteres` : `${b} → más caracteres`
      ).join("<br>");
      document.getElementById("salida").innerHTML = salida;
    }