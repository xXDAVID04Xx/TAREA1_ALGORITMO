function dividirVariasOraciones() {
  let oraciones = ["Me gusta mucho estudiar en casa", "Estudia tus materias con regularidad"];
  let salida = oraciones.map((o,i) => 
    `Oración ${i+1}: ${o.split(" ").join(", ")}`
  ).join("<br>");
  document.getElementById("salida").innerHTML = salida;
}