function contarCaracterEnTextos() {
  let datos = [["Utiliza el celular","i"], ["No molestar","o"]];
  let salida = datos.map(([t,c], i) => 
    `En el ${i+1}º, "${c}" aparece ${t.toLowerCase().split(c).length - 1} veces.`
  ).join("<br>");
  document.getElementById("salida").innerHTML = salida;
}