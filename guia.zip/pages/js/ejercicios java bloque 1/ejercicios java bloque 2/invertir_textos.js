function invertirTextos() {
  let textos = ["Medellin", "Argentina"];
  let salida = textos.map(t => `${t} → ${t.split("").reverse().join("")}`).join("<br>");
  document.getElementById("salida").innerHTML = salida;
}