function reemplazarCaracteresEnTextos() {
  let textos = ["Procesador", "Calor"];
  let salida = textos.map(t => t.replace(/o/gi, "+")).join("<br>");
  document.getElementById("salida").innerHTML = salida;
}