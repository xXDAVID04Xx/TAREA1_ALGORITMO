function compararLongitudes() {
  let pares = [["Alberto","Ramiro"], ["Jaime","Roberto"]];
  let salida = pares.map(([a,b]) => 
    a.length > b.length ? `${a} tiene más letras que ${b}.` : `${b} tiene más letras que ${a}.`
  ).join("<br>");
  document.getElementById("salida").innerHTML = salida;
}