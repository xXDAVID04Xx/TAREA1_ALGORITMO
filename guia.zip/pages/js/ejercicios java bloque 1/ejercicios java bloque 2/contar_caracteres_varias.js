function contarCaracteres_varios() {
  let palabras = ["Mesas", "Sillas", "Modular"];
  let salida = palabras.map(p => `${p} tiene ${p.length} letras.`).join("<br>");
  document.getElementById("salida").innerHTML = salida;
}