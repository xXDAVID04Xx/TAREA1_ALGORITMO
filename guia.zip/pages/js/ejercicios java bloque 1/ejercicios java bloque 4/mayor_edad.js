function mayoresDeEdadArreglo() {
  let arr = [17, 24, 20, 32, 14];
  let mayores = arr.filter(n => n >= 18).length;
  document.getElementById("salida").innerText = "Mayores de edad: " + mayores;
}