function sumaDosArreglos() {
  let A = [4, 6, 8];
  let B = [3, 5, 7];
  let C = A.map((n,i) => n + B[i]);
  document.getElementById("salida").innerText = "C=[" + C.join(", ") + "]";
}