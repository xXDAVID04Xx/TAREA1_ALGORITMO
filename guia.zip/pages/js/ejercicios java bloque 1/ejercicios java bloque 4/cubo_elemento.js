function cuboElementosArreglo() {
  let arr = [8, 12, 16];
  let cubos = arr.map(n => n ** 3);
  document.getElementById("salida").innerText = "[" + cubos.join(", ") + "]";
}