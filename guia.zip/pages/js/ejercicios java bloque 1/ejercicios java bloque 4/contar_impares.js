function contarImparesArreglo() {
  let arr = [4, 7, 9, 10, 14];
  let impares = arr.filter(n => n % 2 !== 0).length;
  document.getElementById("salida").innerText = "Cantidad de impares: " + impares;
}