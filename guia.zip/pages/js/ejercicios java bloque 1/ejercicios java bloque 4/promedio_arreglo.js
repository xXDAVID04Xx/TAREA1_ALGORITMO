function promedioArreglo() {
  let arr = [8, 4, 2, 9, 5];
  let promedio = arr.reduce((a,b)=>a+b,0) / arr.length;
  document.getElementById("salida").innerText = "El promedio es " + promedio;
}