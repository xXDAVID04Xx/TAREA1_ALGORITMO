function concatenarPalabrasArreglo() {
  let arr = ["No", "me", "gusta", "despertar", "temprano"];
  let frase = arr.join(" ");
  document.getElementById("salida").innerText = frase;
}