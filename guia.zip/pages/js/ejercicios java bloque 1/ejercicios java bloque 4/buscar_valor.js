function buscarValorEnArreglo() {
  let arr = [6, 10, 17, 25];
  let valor = 17;
  let existe = arr.includes(valor);
  document.getElementById("salida").innerText = 
    existe ? `El valor ${valor} sí existe en el arreglo.` : `El valor ${valor} no existe en el arreglo.`;
}