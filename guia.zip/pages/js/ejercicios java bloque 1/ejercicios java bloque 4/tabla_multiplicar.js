function tablaMultiplicarElementos() {
  let arr = [12, 8];
  let salida = arr.map(num => {
    let tabla = [];
    for (let i = 1; i <= 10; i++) {
      tabla.push(num * i);
    }
    return `Tabla de ${num}: ${tabla.join(", ")}`;
  }).join("<br>");
  document.getElementById("salida").innerHTML = salida;
}