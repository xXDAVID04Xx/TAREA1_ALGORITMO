function copiarParesArreglo() {
  let arr = [6, 10, 13, 16, 27];
  let pares = arr.filter(n => n % 2 === 0);
  document.getElementById("salida").innerText = "[" + pares.join(", ") + "]";
}