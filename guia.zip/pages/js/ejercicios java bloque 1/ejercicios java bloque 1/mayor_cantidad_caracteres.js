function fraseMasLarga() {
  let f1 = "No quiero dormir";
  let f2 = "Me gustan los videojuegos";
  let resultado = f1.length > f2.length ? "La frase '" + f1 + "' tiene más caracteres."
                : f2.length > f1.length ? "La frase '" + f2 + "' tiene más caracteres."
                : "Ambas frases tienen la misma cantidad de caracteres.";
  document.getElementById("salida").innerText = resultado;
}