function verificarPalindromo() {
  let palabra = "oso";
  let esPalindromo = palabra.toLowerCase() === palabra.toLowerCase().split("").reverse().join("");
  document.getElementById("salida").innerText = esPalindromo 
    ? "La palabra '" + palabra + "' es un palíndromo."
    : "La palabra '" + palabra + "' no es un palíndromo.";
}