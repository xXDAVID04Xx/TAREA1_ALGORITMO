function reemplazarCaracteres() {
  let texto = "Animador";
  let resultado = texto.replace(/a/gi, "#");
  document.getElementById("salida").innerText = resultado;
}