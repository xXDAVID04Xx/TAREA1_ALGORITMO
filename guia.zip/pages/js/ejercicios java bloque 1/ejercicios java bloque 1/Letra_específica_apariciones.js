function contarLetra() {
  let texto = "Me gusta dormir todo el día";
  let letra = "o";
  let veces = texto.toLowerCase().split(letra).length - 1;
  document.getElementById("salida").innerText = "La letra '" + letra + "' aparece " + veces + " veces.";
}