function invertirTexto() {
  let texto = "Árbol";
  let invertido = texto.split("").reverse().join("");
  document.getElementById("salida").innerText = invertido;
}