function verificarCaracteres() {
  let palabra = "computadora";
  document.getElementById("salida").innerText = "La palabra tiene " + palabra.length + " letras.";
}