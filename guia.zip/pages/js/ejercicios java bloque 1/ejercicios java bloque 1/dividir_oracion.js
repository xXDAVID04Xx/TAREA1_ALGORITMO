function dividirOracion() {
  let oracion = "Me gusta salir con mis amigos";
  let palabras = oracion.split(" ");
  document.getElementById("salida").innerHTML = palabras.join("<br>");
}