function compararLongitudes() {
  let a = "Oyola", b = "Rodríguez";
  let resultado = a.length > b.length ? "El apellido '" + a + "' tiene más letras."
                 : b.length > a.length ? "El apellido '" + b + "' tiene más letras."
                 : "Ambos tienen la misma cantidad de letras.";
  document.getElementById("salida").innerText = resultado;
}