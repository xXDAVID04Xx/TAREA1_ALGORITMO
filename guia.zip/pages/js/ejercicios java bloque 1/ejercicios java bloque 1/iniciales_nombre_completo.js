function obtenerIniciales() {
  let nombre = "Jhon Alex Castaño";
  let iniciales = nombre.split(" ").map(p => p[0].toUpperCase()).join(".") + ".";
  document.getElementById("salida").innerText = iniciales;
}