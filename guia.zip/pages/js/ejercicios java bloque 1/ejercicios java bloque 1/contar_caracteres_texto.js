function contarApariciones() {
  let texto = "Examen de programación";
  let caracter = "m";
  let veces = texto.toLowerCase().split(caracter).length - 1;
  document.getElementById("salida").innerText = "La letra '" + caracter + "' aparece " + veces + " veces.";
}