function factorial(n){
  let f=1;
  for(let i=1;i<=n;i++){ f*=i; }
  return f;
}
function factorial1() {
  let num=6;
  document.getElementById("salida").innerText = factorial(num);
}