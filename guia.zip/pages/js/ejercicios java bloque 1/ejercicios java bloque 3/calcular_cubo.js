function calcularCubo(numeros) {
  let a=2, b=5, c=7;
  let c1=a**3, c2=b**3, c3=c**3;
  document.getElementById("salida").innerText = c1 + ", " + c2 + ", " + c3;
}