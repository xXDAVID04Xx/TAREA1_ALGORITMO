function tablaMultiplicar(numero) {
  let num=7;
  let tabla="";
  for(let i=1; i<=10; i++){
    tabla += (num*i) + (i<10 ? ", " : "");
  }
  document.getElementById("salida").innerText = tabla;
}