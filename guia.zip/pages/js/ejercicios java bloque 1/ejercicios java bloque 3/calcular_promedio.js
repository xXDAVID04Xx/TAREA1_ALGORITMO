function calcularPromedio(numeros) {
  let a=10, b=20, c=30, d=25, e=15;
  let promedio = (a+b+c+d+e)/5;
  document.getElementById("salida").innerText = "Promedio = " + promedio;
}