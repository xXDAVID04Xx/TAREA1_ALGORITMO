function sumarGrupos(grupoA, grupoB) {
  let a1=3, a2=6, a3=9;
  let b1=4, b2=8, b3=12;
  let c1=a1+b1, c2=a2+b2, c3=a3+b3;
  document.getElementById("salida").innerText = "C=(" + c1 + ", " + c2 + ", " + c3 + ")";
}