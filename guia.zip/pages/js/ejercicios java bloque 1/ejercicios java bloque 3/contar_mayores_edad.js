function contarMayoresDeEdad(edades) {
  let e1=16, e2=21, e3=17, e4=19, e5=25;
  let mayores=0;
  if (e1>=18) mayores++;
  if (e2>=18) mayores++;
  if (e3>=18) mayores++;
  if (e4>=18) mayores++;
  if (e5>=18) mayores++;
  document.getElementById("salida").innerText = "Mayores de edad: " + mayores;
}