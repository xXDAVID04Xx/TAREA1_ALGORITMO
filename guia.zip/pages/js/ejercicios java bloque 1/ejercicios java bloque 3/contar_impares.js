function contarImpares(numeros) {
  let a=4, b=9, c=12, d=7, e=5;
  let impares = 0;
  if (a%2!==0) impares++;
  if (b%2!==0) impares++;
  if (c%2!==0) impares++;
  if (d%2!==0) impares++;
  if (e%2!==0) impares++;
  document.getElementById("salida").innerText = "Cantidad de impares = " + impares;
}