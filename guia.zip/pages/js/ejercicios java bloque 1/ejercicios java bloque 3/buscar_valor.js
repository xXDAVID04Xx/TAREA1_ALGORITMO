function buscarValor(numeros, valor) {
  let n1=12, n2=24, n3=36, n4=48;
  let buscar=36;
  let existe = (n1===buscar || n2===buscar || n3===buscar || n4===buscar);
  document.getElementById("salida").innerText = 
    existe ? "El valor " + buscar + " existe." : "El valor " + buscar + " no existe.";
}