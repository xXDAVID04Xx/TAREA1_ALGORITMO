function mostrarPares(numeros) {
  let a=13, b=20, c=7, d=42;
  let pares="";
  if (a%2===0) pares+=a+" ";
  if (b%2===0) pares+=b+" ";
  if (c%2===0) pares+=c+" ";
  if (d%2===0) pares+=d+" ";
  document.getElementById("salida").innerText = pares.trim();
}