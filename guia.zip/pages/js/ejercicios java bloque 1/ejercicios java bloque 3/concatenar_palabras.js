function concatenarPalabras(palabra1, palabra2, palabra3) {
  let p1="Estoy", p2="muy", p3="bien";
  let frase = p1 + " " + p2 + " " + p3;
  document.getElementById("salida").innerText = frase;
}